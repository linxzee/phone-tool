// This file can be used for general JavaScript logic specific to index.html
// without conflicts with the navbar functionality.